<a name="0.2.2"></a>
## [0.2.2](https://github.com/advanced-rest-client/arc-privacy-settings-panel/compare/0.2.1...0.2.2) (2017-10-10)




<a name="0.2.1"></a>
## [0.2.1](https://github.com/advanced-rest-client/arc-privacy-settings-panel/compare/0.1.1...0.2.1) (2017-10-10)


### Update

* Updated the element for new API. ([d227f517da259565e30b06a4a65afd709fc35109](https://github.com/advanced-rest-client/arc-privacy-settings-panel/commit/d227f517da259565e30b06a4a65afd709fc35109))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-19)


### Update

* Added sauce configuration for tests ([f18aef4af9dcaa87d58010e4b85e004162d86997](https://github.com/advanced-rest-client/arc-privacy-settings-panel/commit/f18aef4af9dcaa87d58010e4b85e004162d86997))



