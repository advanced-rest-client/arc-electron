<a name="1.1.2"></a>
## [1.1.2](https://github.com/advanced-rest-client/bottom-sheet/compare/1.1.1...1.1.2) (2017-10-03)




<a name="1.1.1"></a>
## [1.1.1](https://github.com/advanced-rest-client/bottom-sheet/compare/1.0.5...1.1.1) (2017-10-03)


### New

* Added support for scrollable content. ([ef97ff907f1c6f755c03f447498ab3717bad8e59](https://github.com/advanced-rest-client/bottom-sheet/commit/ef97ff907f1c6f755c03f447498ab3717bad8e59))

### Update

* Changed testing to new model. ([6b4b27f8e7422f5ea17daead83581b95448069f3](https://github.com/advanced-rest-client/bottom-sheet/commit/6b4b27f8e7422f5ea17daead83581b95448069f3))



<a name="1.0.5"></a>
## [1.0.5](https://github.com/advanced-rest-client/bottom-sheet/compare/1.0.3...1.0.5) (2017-09-23)


### Fix

* Fixed "hidden" attribute styles ([c8738afaae88d7871d4d15a19b6f30d1799b86b1](https://github.com/advanced-rest-client/bottom-sheet/commit/c8738afaae88d7871d4d15a19b6f30d1799b86b1))

### Update

* Added new Travis configuration ([912d29dab2facfdb2b1b4ef19a7a8955cd2874ef](https://github.com/advanced-rest-client/bottom-sheet/commit/912d29dab2facfdb2b1b4ef19a7a8955cd2874ef))



<a name="1.0.4"></a>
## [1.0.4](https://github.com/advanced-rest-client/bottom-sheet/compare/1.0.3...v1.0.4) (2016-11-20)


### Update

* Added new Travis configuration ([912d29dab2facfdb2b1b4ef19a7a8955cd2874ef](https://github.com/advanced-rest-client/bottom-sheet/commit/912d29dab2facfdb2b1b4ef19a7a8955cd2874ef))



<a name="1.0.3"></a>
## [1.0.3](https://github.com/advanced-rest-client/bottom-sheet/compare/1.0.1...v1.0.3) (2016-10-06)


### New

* Added hero image ([3dbc9873a319397d383a159772bee5007f72f477](https://github.com/advanced-rest-client/bottom-sheet/commit/3dbc9873a319397d383a159772bee5007f72f477))



<a name="1.0.2"></a>
## [1.0.2](https://github.com/advanced-rest-client/bottom-sheet/compare/1.0.1...v1.0.2) (2016-09-29)




<a name="1.0.1"></a>
## 1.0.1 (2016-09-12)


### Update

* Updated dependencies tree ([fe7e9efe9e5d3c22594a2c8d5ef7ea20fedcc0f3](https://github.com/advanced-rest-client/bottom-sheet/commit/fe7e9efe9e5d3c22594a2c8d5ef7ea20fedcc0f3))



