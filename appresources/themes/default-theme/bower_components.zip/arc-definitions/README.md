[![Build Status](https://travis-ci.org/advanced-rest-client/arc-definitions.svg?branch=stage)](https://travis-ci.org/advanced-rest-client/arc-definitions)  

# arc-definitions
 global console 