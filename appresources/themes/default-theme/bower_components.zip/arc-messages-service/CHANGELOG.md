<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-messages-service/compare/0.1.4...0.1.5) (2017-10-13)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-messages-service/compare/0.1.3...0.1.4) (2017-10-13)


### Fix

* Fixed endpointUri value. ([325474f560fb1b4021e94544514c64790ec0523a](https://github.com/advanced-rest-client/arc-messages-service/commit/325474f560fb1b4021e94544514c64790ec0523a))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-messages-service/compare/0.1.2...0.1.3) (2017-10-13)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-messages-service/compare/0.1.1...0.1.2) (2017-10-13)


### Update

* Added support for updating messages objects. ([765f7fe34fe155a48c3ed6c45aa095ea759dd658](https://github.com/advanced-rest-client/arc-messages-service/commit/765f7fe34fe155a48c3ed6c45aa095ea759dd658))



<a name="0.1.1"></a>
## 0.1.1 (2017-10-12)


### Update

* Added sauce configuration for tests ([14aaddd18976b8f7c6b9c779fa9d19122a79b028](https://github.com/advanced-rest-client/arc-messages-service/commit/14aaddd18976b8f7c6b9c779fa9d19122a79b028))
* Removed unsupported browsers from tests ([a398a087ca01c63d27ae41f0f2ee2a6671769a9d](https://github.com/advanced-rest-client/arc-messages-service/commit/a398a087ca01c63d27ae41f0f2ee2a6671769a9d))



