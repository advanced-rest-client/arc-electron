<a name="0.1.1"></a>
## 0.1.1 (2017-06-20)


### Update

* Added sauce labs credentials ([2dff0d0191d125ecc6f6561d1744c7167bb9ffcf](https://github.com/advanced-rest-client/arc-loader-screen/commit/2dff0d0191d125ecc6f6561d1744c7167bb9ffcf))



