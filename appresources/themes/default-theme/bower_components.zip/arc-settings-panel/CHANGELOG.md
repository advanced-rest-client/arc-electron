<a name="0.2.4"></a>
## [0.2.4](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.2.3...0.2.4) (2017-12-03)




<a name="0.2.3"></a>
## [0.2.3](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.2.2...0.2.3) (2017-12-03)


### Update

* Adding light DOM access. ([accac4f3f480d414640607f790bc400cdd982611](https://github.com/advanced-rest-client/arc-settings-panel/commit/accac4f3f480d414640607f790bc400cdd982611))



<a name="0.2.2"></a>
## [0.2.2](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.2.1...0.2.2) (2017-10-10)




<a name="0.2.1"></a>
## [0.2.1](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.1.5...0.2.1) (2017-10-10)


### Update

* Updated analytics settings to new system. ([886be857de14180e86c8e6420c9f65d431677107](https://github.com/advanced-rest-client/arc-settings-panel/commit/886be857de14180e86c8e6420c9f65d431677107))
* Updated initialization of the element ([c51b1549d2575144d974203612bad8274c006463](https://github.com/advanced-rest-client/arc-settings-panel/commit/c51b1549d2575144d974203612bad8274c006463))
* Updated version of the privacy settings panel ([ff15df329c7f51c86d30a03833455e1e1779148c](https://github.com/advanced-rest-client/arc-settings-panel/commit/ff15df329c7f51c86d30a03833455e1e1779148c))



<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.1.4...0.1.5) (2017-10-09)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.1.3...0.1.4) (2017-10-09)


### New

* Added openable panel behavior ([262d45538028388dc0084d034d9b34baed6dbc29](https://github.com/advanced-rest-client/arc-settings-panel/commit/262d45538028388dc0084d034d9b34baed6dbc29))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.1.2...0.1.3) (2017-10-02)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-settings-panel/compare/0.1.1...0.1.2) (2017-10-02)


### Update

* Added support for dta panel subpages ([c6358646a534f2a9dd9d67c27bd29f154f2da3a0](https://github.com/advanced-rest-client/arc-settings-panel/commit/c6358646a534f2a9dd9d67c27bd29f154f2da3a0))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-19)


### Update

* Added sauce configuration for tests ([32b62d18b0be612efc54b2ae152bec5184d04a33](https://github.com/advanced-rest-client/arc-settings-panel/commit/32b62d18b0be612efc54b2ae152bec5184d04a33))



