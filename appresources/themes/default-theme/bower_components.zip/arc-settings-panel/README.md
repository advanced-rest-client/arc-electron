[![Build Status](https://travis-ci.org/advanced-rest-client/arc-settings-panel.svg?branch=stage)](https://travis-ci.org/advanced-rest-client/arc-settings-panel)  

# arc-settings-panel

Settings panel for ARC.

This elemet and whole settings data system must change so there's no point
of documenting it right now.

### Example
```
<arc-settings-panel></arc-settings-panel>
```

### Styling
`<arc-settings-panel>` provides the following custom properties and mixins for styling:

Custom property | Description | Default
----------------|-------------|----------
`--arc-settings-panel` | Mixin applied to the element | `{}`

