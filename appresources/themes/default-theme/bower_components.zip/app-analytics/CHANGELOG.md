<a name="1.1.1"></a>
## [1.1.1](https://github.com/advanced-rest-client/app-analytics/compare/1.0.15...1.1.1) (2017-10-10)


### Update

* Removed support for disabling GA. Remove element from the DOM instead. ([d6d04a56d63495b3b724f53eb355ccab7ccd46ef](https://github.com/advanced-rest-client/app-analytics/commit/d6d04a56d63495b3b724f53eb355ccab7ccd46ef))



<a name="1.0.16"></a>
## [1.0.16](https://github.com/advanced-rest-client/app-analytics/compare/1.0.15...v1.0.16) (2017-07-08)




<a name="1.0.15"></a>
## [1.0.15](https://github.com/advanced-rest-client/app-analytics/compare/1.0.14...v1.0.15) (2017-07-08)


### Fix

* Fixed tests ([2a67ff6c6940bfecd923088c11a7b86124c47b33](https://github.com/advanced-rest-client/app-analytics/commit/2a67ff6c6940bfecd923088c11a7b86124c47b33))



<a name="1.0.14"></a>
## [1.0.14](https://github.com/advanced-rest-client/app-analytics/compare/1.0.13...v1.0.14) (2017-05-31)


### Fix

* Many small bug fixes. ([5c5acbb93dda7efcd21845f02ea2f300941e5dac](https://github.com/advanced-rest-client/app-analytics/commit/5c5acbb93dda7efcd21845f02ea2f300941e5dac))

### New

* Added new tests. Updated old tests ([8a9828e9fc612c14ae221b511df827fcb4d1410f](https://github.com/advanced-rest-client/app-analytics/commit/8a9828e9fc612c14ae221b511df827fcb4d1410f))

### Update

* Added safari 10 to testd browsers ([f59dc67afa6980e67336023b4240c7690d8b73d9](https://github.com/advanced-rest-client/app-analytics/commit/f59dc67afa6980e67336023b4240c7690d8b73d9))



<a name="1.0.13"></a>
## [1.0.13](https://github.com/advanced-rest-client/app-analytics/compare/1.0.12...v1.0.13) (2016-11-20)




<a name="1.0.12"></a>
## [1.0.12](https://github.com/advanced-rest-client/app-analytics/compare/1.0.11...v1.0.12) (2016-11-20)


### Update

* Changed method how the element initialize variables ([824ba1c9305c6a030ff820332c100d322e2eb7d6](https://github.com/advanced-rest-client/app-analytics/commit/824ba1c9305c6a030ff820332c100d322e2eb7d6))
* disabled ES6 comability mode ([3597d506ef1f68cf7a7dbe2c18769572e00d239f](https://github.com/advanced-rest-client/app-analytics/commit/3597d506ef1f68cf7a7dbe2c18769572e00d239f))
* Removed gulp tasks ([c3cb02e9f56f621e5ea5ae935f2d7c2b48b95080](https://github.com/advanced-rest-client/app-analytics/commit/c3cb02e9f56f621e5ea5ae935f2d7c2b48b95080))
* testing disableTracking property ([9c48b98e521ddd7aff7fd7d0d7fa00decd691359](https://github.com/advanced-rest-client/app-analytics/commit/9c48b98e521ddd7aff7fd7d0d7fa00decd691359))



<a name="1.0.11"></a>
## [1.0.11](https://github.com/advanced-rest-client/app-analytics/compare/1.0.10...v1.0.11) (2016-11-10)


### Fix

* Fixed issue #1. Also refactored code to not use ES6 function. Added polyfil to find index function ([a1980f6378f14f657d3a0e871862b2d4e56650c9](https://github.com/advanced-rest-client/app-analytics/commit/a1980f6378f14f657d3a0e871862b2d4e56650c9)), closes [#1](https://github.com/advanced-rest-client/app-analytics/issues/1)



<a name="1.0.10"></a>
## [1.0.10](https://github.com/advanced-rest-client/app-analytics/compare/1.0.5...v1.0.10) (2016-10-29)


### Docs

* updated demo page ([56d6ae41785bd8f54c18ce6fe231976a53e25b9f](https://github.com/advanced-rest-client/app-analytics/commit/56d6ae41785bd8f54c18ce6fe231976a53e25b9f))

### Fix

* Added type checking when trying to access properties in strict mode ([a76e0dec0bbfe91a623df7183d37653874e7b8a5](https://github.com/advanced-rest-client/app-analytics/commit/a76e0dec0bbfe91a623df7183d37653874e7b8a5))
* Fixing parameters assignment ([913813f0db4107ab9b79a95d2797e0a94d5d8563](https://github.com/advanced-rest-client/app-analytics/commit/913813f0db4107ab9b79a95d2797e0a94d5d8563))

### Update

* Added content type header for the request ([ce6ba42bf0ff1aadf6e3c74d029fe981cdf1fc06](https://github.com/advanced-rest-client/app-analytics/commit/ce6ba42bf0ff1aadf6e3c74d029fe981cdf1fc06))



<a name="1.0.9"></a>
## [1.0.9](https://github.com/advanced-rest-client/app-analytics/compare/1.0.5...v1.0.9) (2016-10-29)


### Docs

* updated demo page ([56d6ae41785bd8f54c18ce6fe231976a53e25b9f](https://github.com/advanced-rest-client/app-analytics/commit/56d6ae41785bd8f54c18ce6fe231976a53e25b9f))

### Fix

* Added type checking when trying to access properties in strict mode ([a76e0dec0bbfe91a623df7183d37653874e7b8a5](https://github.com/advanced-rest-client/app-analytics/commit/a76e0dec0bbfe91a623df7183d37653874e7b8a5))
* Fixing parameters assignment ([913813f0db4107ab9b79a95d2797e0a94d5d8563](https://github.com/advanced-rest-client/app-analytics/commit/913813f0db4107ab9b79a95d2797e0a94d5d8563))



<a name="1.0.8"></a>
## [1.0.8](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.8) (2016-10-25)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))
* Updated docs for new API ([2f7275b1b25fd0de47bb59978b023ed2f890bfa9](https://github.com/advanced-rest-client/app-analytics/commit/2f7275b1b25fd0de47bb59978b023ed2f890bfa9))

### Fix

* Added type checking when trying to access properties in strict mode ([a76e0dec0bbfe91a623df7183d37653874e7b8a5](https://github.com/advanced-rest-client/app-analytics/commit/a76e0dec0bbfe91a623df7183d37653874e7b8a5))
* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))
* Fixing parameters assignment ([913813f0db4107ab9b79a95d2797e0a94d5d8563](https://github.com/advanced-rest-client/app-analytics/commit/913813f0db4107ab9b79a95d2797e0a94d5d8563))

### New

* Added custom metrics / dimensions to the event details ([12798f3e2f33a016eb52ca52b4564fb89c608970](https://github.com/advanced-rest-client/app-analytics/commit/12798f3e2f33a016eb52ca52b4564fb89c608970))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))
* Removed dependency to chrome platform analytics. Updated docs ([69a8a6844a976160c4626b2764ebc283a9d1ce6e](https://github.com/advanced-rest-client/app-analytics/commit/69a8a6844a976160c4626b2764ebc283a9d1ce6e))



<a name="1.0.7"></a>
## [1.0.7](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.7) (2016-10-25)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))
* Updated docs for new API ([2f7275b1b25fd0de47bb59978b023ed2f890bfa9](https://github.com/advanced-rest-client/app-analytics/commit/2f7275b1b25fd0de47bb59978b023ed2f890bfa9))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))
* Fixing parameters assignment ([913813f0db4107ab9b79a95d2797e0a94d5d8563](https://github.com/advanced-rest-client/app-analytics/commit/913813f0db4107ab9b79a95d2797e0a94d5d8563))

### New

* Added custom metrics / dimensions to the event details ([12798f3e2f33a016eb52ca52b4564fb89c608970](https://github.com/advanced-rest-client/app-analytics/commit/12798f3e2f33a016eb52ca52b4564fb89c608970))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))
* Removed dependency to chrome platform analytics. Updated docs ([69a8a6844a976160c4626b2764ebc283a9d1ce6e](https://github.com/advanced-rest-client/app-analytics/commit/69a8a6844a976160c4626b2764ebc283a9d1ce6e))



<a name="1.0.6"></a>
## [1.0.6](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.6) (2016-10-25)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))
* Updated docs for new API ([2f7275b1b25fd0de47bb59978b023ed2f890bfa9](https://github.com/advanced-rest-client/app-analytics/commit/2f7275b1b25fd0de47bb59978b023ed2f890bfa9))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))

### New

* Added custom metrics / dimensions to the event details ([12798f3e2f33a016eb52ca52b4564fb89c608970](https://github.com/advanced-rest-client/app-analytics/commit/12798f3e2f33a016eb52ca52b4564fb89c608970))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))
* Removed dependency to chrome platform analytics. Updated docs ([69a8a6844a976160c4626b2764ebc283a9d1ce6e](https://github.com/advanced-rest-client/app-analytics/commit/69a8a6844a976160c4626b2764ebc283a9d1ce6e))



<a name="1.0.5"></a>
## [1.0.5](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.5) (2016-10-23)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))
* Updated docs for new API ([2f7275b1b25fd0de47bb59978b023ed2f890bfa9](https://github.com/advanced-rest-client/app-analytics/commit/2f7275b1b25fd0de47bb59978b023ed2f890bfa9))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))

### New

* Added custom metrics / dimensions to the event details ([12798f3e2f33a016eb52ca52b4564fb89c608970](https://github.com/advanced-rest-client/app-analytics/commit/12798f3e2f33a016eb52ca52b4564fb89c608970))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))
* Removed dependency to chrome platform analytics. Updated docs ([69a8a6844a976160c4626b2764ebc283a9d1ce6e](https://github.com/advanced-rest-client/app-analytics/commit/69a8a6844a976160c4626b2764ebc283a9d1ce6e))



<a name="1.0.4"></a>
## [1.0.4](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.4) (2016-10-23)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))
* Updated docs for new API ([2f7275b1b25fd0de47bb59978b023ed2f890bfa9](https://github.com/advanced-rest-client/app-analytics/commit/2f7275b1b25fd0de47bb59978b023ed2f890bfa9))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))

### New

* Added custom metrics / dimensions to the event details ([12798f3e2f33a016eb52ca52b4564fb89c608970](https://github.com/advanced-rest-client/app-analytics/commit/12798f3e2f33a016eb52ca52b4564fb89c608970))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))



<a name="1.0.3"></a>
## [1.0.3](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.3) (2016-10-12)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))

### Update

* Added hero image ([c995869fef9cb907ba3c7625d953f77c4528a834](https://github.com/advanced-rest-client/app-analytics/commit/c995869fef9cb907ba3c7625d953f77c4528a834))



<a name="1.0.2"></a>
## [1.0.2](https://github.com/advanced-rest-client/app-analytics/compare/1.0.1...v1.0.2) (2016-10-12)


### Docs

* Updated docs ([174972dc1ba44ea5a63bc33cac7541ee9937a375](https://github.com/advanced-rest-client/app-analytics/commit/174972dc1ba44ea5a63bc33cac7541ee9937a375))

### Fix

* Fixed issues with database initialization. Now analytics works properly. Added offline support. Added ability to disable analytics ([9ae3b8a4cc248c4ae450b67579a21b8c65268443](https://github.com/advanced-rest-client/app-analytics/commit/9ae3b8a4cc248c4ae450b67579a21b8c65268443))



<a name="1.0.1"></a>
## 1.0.1 (2016-10-11)




