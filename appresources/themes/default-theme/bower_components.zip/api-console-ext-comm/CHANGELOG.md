<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/api-console-ext-comm/compare/0.1.3...v0.1.4) (2017-04-10)




<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/api-console-ext-comm/compare/0.1.1...v0.1.3) (2017-04-10)


### Update

* Added support for OAuth token requests ([af82902b248bcc6b0ca4277b81503adb1497395d](https://github.com/advanced-rest-client/api-console-ext-comm/commit/af82902b248bcc6b0ca4277b81503adb1497395d))



<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/api-console-ext-comm/compare/0.1.1...v0.1.2) (2017-04-10)




<a name="0.1.1"></a>
## 0.1.1 (2017-03-29)


### Update

* Updated travis configuration - added sauce connect ([8c9be57eed83766e1a231461100640eae63c4626](https://github.com/advanced-rest-client/api-console-ext-comm/commit/8c9be57eed83766e1a231461100640eae63c4626))



