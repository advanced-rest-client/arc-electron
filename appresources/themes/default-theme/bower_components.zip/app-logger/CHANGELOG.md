<a name="0.1.1"></a>
## [0.1.1](https://github.com/advanced-rest-client/app-logger/compare/0.0.5...0.1.1) (2017-10-03)


### Fix

* Fixed stack getter ([95b7851e5908d4729287643859ca478a751f614d](https://github.com/advanced-rest-client/app-logger/commit/95b7851e5908d4729287643859ca478a751f614d))
* Fixed tests ([3a3f642643b88552277b794552b0d661a4e61be0](https://github.com/advanced-rest-client/app-logger/commit/3a3f642643b88552277b794552b0d661a4e61be0))

### Update

* Added new Travis configuration ([0ebba8ad7d8ab78d25b3dc6bbb2d566957fbca96](https://github.com/advanced-rest-client/app-logger/commit/0ebba8ad7d8ab78d25b3dc6bbb2d566957fbca96))
* Updated tests configurqation to new model. ([25dca740c9a6b624ea7384bc98b35fe6b8b66c37](https://github.com/advanced-rest-client/app-logger/commit/25dca740c9a6b624ea7384bc98b35fe6b8b66c37))



<a name="0.0.5"></a>
## 0.0.5 (2016-10-10)


### Docs

* Created docs for the element ([a6b6e44f088de948cbf3e6563945a8c3d42ec24e](https://github.com/advanced-rest-client/app-logger/commit/a6b6e44f088de948cbf3e6563945a8c3d42ec24e))

### Fix

* Added support for complex objects  ([5f7a29a12738fefab1ca5b428dcbaed0f5f22e69](https://github.com/advanced-rest-client/app-logger/commit/5f7a29a12738fefab1ca5b428dcbaed0f5f22e69))
* Even type object now will be saved into the datastore ([ce1e0921373fe41f36769819276438f9e54d9366](https://github.com/advanced-rest-client/app-logger/commit/ce1e0921373fe41f36769819276438f9e54d9366))
* Fixed stack property ([46db43b359a0bf2cfdc55bb535c6c5651730b010](https://github.com/advanced-rest-client/app-logger/commit/46db43b359a0bf2cfdc55bb535c6c5651730b010))

### New

* Added hero image ([8d2b4bd5804bdba1a73289f9f77e8a6df17b403a](https://github.com/advanced-rest-client/app-logger/commit/8d2b4bd5804bdba1a73289f9f77e8a6df17b403a))



<a name="0.0.4"></a>
## 0.0.4 (2016-10-07)


### Docs

* Created docs for the element ([a6b6e44f088de948cbf3e6563945a8c3d42ec24e](https://github.com/advanced-rest-client/app-logger/commit/a6b6e44f088de948cbf3e6563945a8c3d42ec24e))

### Fix

* Added support for complex objects  ([5f7a29a12738fefab1ca5b428dcbaed0f5f22e69](https://github.com/advanced-rest-client/app-logger/commit/5f7a29a12738fefab1ca5b428dcbaed0f5f22e69))
* Fixed stack property ([46db43b359a0bf2cfdc55bb535c6c5651730b010](https://github.com/advanced-rest-client/app-logger/commit/46db43b359a0bf2cfdc55bb535c6c5651730b010))

### New

* Added hero image ([8d2b4bd5804bdba1a73289f9f77e8a6df17b403a](https://github.com/advanced-rest-client/app-logger/commit/8d2b4bd5804bdba1a73289f9f77e8a6df17b403a))



<a name="0.0.3"></a>
## 0.0.3 (2016-10-07)


### Docs

* Created docs for the element ([a6b6e44f088de948cbf3e6563945a8c3d42ec24e](https://github.com/advanced-rest-client/app-logger/commit/a6b6e44f088de948cbf3e6563945a8c3d42ec24e))

### Fix

* Added support for complex objects  ([5f7a29a12738fefab1ca5b428dcbaed0f5f22e69](https://github.com/advanced-rest-client/app-logger/commit/5f7a29a12738fefab1ca5b428dcbaed0f5f22e69))

### New

* Added hero image ([8d2b4bd5804bdba1a73289f9f77e8a6df17b403a](https://github.com/advanced-rest-client/app-logger/commit/8d2b4bd5804bdba1a73289f9f77e8a6df17b403a))



<a name="0.0.2"></a>
## 0.0.2 (2016-10-07)


### Docs

* Created docs for the element ([a6b6e44f088de948cbf3e6563945a8c3d42ec24e](https://github.com/advanced-rest-client/app-logger/commit/a6b6e44f088de948cbf3e6563945a8c3d42ec24e))

### New

* Added hero image ([8d2b4bd5804bdba1a73289f9f77e8a6df17b403a](https://github.com/advanced-rest-client/app-logger/commit/8d2b4bd5804bdba1a73289f9f77e8a6df17b403a))



