<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-onboarding/compare/0.1.2...0.1.3) (2017-10-02)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-onboarding/compare/0.1.1...0.1.2) (2017-10-02)


### Fix

* Fixed saving data in chrome ([d39e8ec6ea6ca60d4be70b50cb813d1e7599addb](https://github.com/advanced-rest-client/arc-onboarding/commit/d39e8ec6ea6ca60d4be70b50cb813d1e7599addb))



<a name="0.1.1"></a>
## 0.1.1 (2017-10-02)


### Fix

* Fixed WCT config file ([7d8f351510815e3899ed8adcecdf1dabff2f721b](https://github.com/advanced-rest-client/arc-onboarding/commit/7d8f351510815e3899ed8adcecdf1dabff2f721b))

### Update

* Added sauce configuration for tests ([e9fa4e6141d2259492449f1c025b986a0ceeeef8](https://github.com/advanced-rest-client/arc-onboarding/commit/e9fa4e6141d2259492449f1c025b986a0ceeeef8))



