[![Build Status](https://travis-ci.org/advanced-rest-client/arc-onboarding.svg?branch=stage)](https://travis-ci.org/advanced-rest-client/arc-onboarding)  

# arc-onboarding

`<arc-onboarding>` Onboarding tutorial for the ARC

### Example
```
<arc-onboarding></arc-onboarding>
```

### Styling
`<arc-onboarding>` provides the following custom properties and mixins for styling:

Custom property | Description | Default
----------------|-------------|----------
`--arc-onboarding` | Mixin applied to the element | `{}`

