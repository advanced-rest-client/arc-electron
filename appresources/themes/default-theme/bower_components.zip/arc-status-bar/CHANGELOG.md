<a name="0.2.5"></a>
## [0.2.5](https://github.com/advanced-rest-client/arc-status-bar/compare/0.2.4...0.2.5) (2017-12-13)




<a name="0.2.4"></a>
## [0.2.4](https://github.com/advanced-rest-client/arc-status-bar/compare/0.2.3...0.2.4) (2017-12-13)


### Update

* Added vertical offset to the variables overlay ([533b11a5cd949143dc3aa1ef2eb71e91a2d65b0a](https://github.com/advanced-rest-client/arc-status-bar/commit/533b11a5cd949143dc3aa1ef2eb71e91a2d65b0a))



<a name="0.2.3"></a>
## [0.2.3](https://github.com/advanced-rest-client/arc-status-bar/compare/0.2.2...0.2.3) (2017-12-13)




<a name="0.2.2"></a>
## [0.2.2](https://github.com/advanced-rest-client/arc-status-bar/compare/0.2.1...0.2.2) (2017-12-13)


### New

* Added variables-preview-overlay element. ([516333444a57916cce38ad6904ab18f3d9ce775c](https://github.com/advanced-rest-client/arc-status-bar/commit/516333444a57916cce38ad6904ab18f3d9ce775c))



<a name="0.2.1"></a>
## 0.2.1 (2017-10-11)


### Breaking

* Replaced message property for content. ([a229fdba5268bfcabfd96de269359e70bcdb2d8d](https://github.com/advanced-rest-client/arc-status-bar/commit/a229fdba5268bfcabfd96de269359e70bcdb2d8d))

### Update

* Added sauce configuration for tests ([c0fd5e1dec873601a9a8c079a1406d24504d0bfb](https://github.com/advanced-rest-client/arc-status-bar/commit/c0fd5e1dec873601a9a8c079a1406d24504d0bfb))



<a name="0.1.1"></a>
## 0.1.1 (2017-08-17)


### Update

* Added sauce configuration for tests ([c0fd5e1dec873601a9a8c079a1406d24504d0bfb](https://github.com/advanced-rest-client/arc-status-bar/commit/c0fd5e1dec873601a9a8c079a1406d24504d0bfb))



