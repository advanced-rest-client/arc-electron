<a name="0.2.4"></a>
## [0.2.4](https://github.com/advanced-rest-client/arc-data-export/compare/0.2.3...0.2.4) (2017-12-22)




<a name="0.2.3"></a>
## [0.2.3](https://github.com/advanced-rest-client/arc-data-export/compare/0.2.2...0.2.3) (2017-12-22)


### New

* Added support for host-rules ([485c3feb4a0176e96852576b9b8c3109adbb8d90](https://github.com/advanced-rest-client/arc-data-export/commit/485c3feb4a0176e96852576b9b8c3109adbb8d90))



<a name="0.2.2"></a>
## [0.2.2](https://github.com/advanced-rest-client/arc-data-export/compare/0.2.1...0.2.2) (2017-11-05)




<a name="0.2.1"></a>
## [0.2.1](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.8...0.2.1) (2017-11-05)


### Fix

* Fixing tests for new API ([764027edaa2843c2f5b5e1e674fba3d11bae217c](https://github.com/advanced-rest-client/arc-data-export/commit/764027edaa2843c2f5b5e1e674fba3d11bae217c))

### Update

* Updated API to returns promise after the object is exported. ([0171e1656b7b340380221f520db9a94db3677721](https://github.com/advanced-rest-client/arc-data-export/commit/0171e1656b7b340380221f520db9a94db3677721))



<a name="0.1.8"></a>
## [0.1.8](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.7...0.1.8) (2017-11-05)




<a name="0.1.7"></a>
## [0.1.7](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.6...0.1.7) (2017-11-05)


### Update

* Added "destination" property for data export. ([5263c3be1b276d1b7d7f0aca124acc83cb5a20bc](https://github.com/advanced-rest-client/arc-data-export/commit/5263c3be1b276d1b7d7f0aca124acc83cb5a20bc))



<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.4...0.1.6) (2017-10-02)


### Update

* Added `key` property to headers and variables export object. ([4ff690e3c6c10dde8ce807e2cb9b141c6cf8dce6](https://github.com/advanced-rest-client/arc-data-export/commit/4ff690e3c6c10dde8ce807e2cb9b141c6cf8dce6))
* Added `key` property to headers and variables export object. ([e3ad70468b0fbca5e0f519f5b6e5ff13d8a6e4fb](https://github.com/advanced-rest-client/arc-data-export/commit/e3ad70468b0fbca5e0f519f5b6e5ff13d8a6e4fb))



<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.4...0.1.5) (2017-09-18)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.3...0.1.4) (2017-09-18)


### Fix

* Fixed test ([6cf9dcf93e91426745ea8e3f27cc5d08811ef857](https://github.com/advanced-rest-client/arc-data-export/commit/6cf9dcf93e91426745ea8e3f27cc5d08811ef857))
* The `_prepareDataHandler` now fires `export-data` after Promise resolves. ([03f010a8543103b8c79cbf8ad22c3cf9a802704d](https://github.com/advanced-rest-client/arc-data-export/commit/03f010a8543103b8c79cbf8ad22c3cf9a802704d))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.2...0.1.3) (2017-09-18)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-data-export/compare/0.1.1...0.1.2) (2017-09-18)


### New

* Adding support for suggested filename ([441d13013e39b5510cf31251396a8cc96df17498](https://github.com/advanced-rest-client/arc-data-export/commit/441d13013e39b5510cf31251396a8cc96df17498))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-12)


### Update

* Added sauce configuration for tests ([d9ff5f13fcfc592cca081a2cdc88a29352de8300](https://github.com/advanced-rest-client/arc-data-export/commit/d9ff5f13fcfc592cca081a2cdc88a29352de8300))



