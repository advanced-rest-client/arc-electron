<a name="0.0.2"></a>
## 0.0.2 (2017-10-14)


### Update

* Added sauce configuration for tests ([59f219cdba071ca0ecf6678e05d829719c70f2ad](https://github.com/advanced-rest-client/arc-title/commit/59f219cdba071ca0ecf6678e05d829719c70f2ad))



