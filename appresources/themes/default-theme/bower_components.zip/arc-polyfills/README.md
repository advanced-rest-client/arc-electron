[![Build Status](https://travis-ci.org/advanced-rest-client/arc-polyfills.svg?branch=stage)](https://travis-ci.org/advanced-rest-client/arc-polyfills)  

# arc-polyfills

`<arc-polyfills>` Set of web polyfills used in ARC project

Just import the element into your element / project and it will provide polyfills for most of
APIs used by the ARC elements.

```html
<head>
...
<link rel="import" href="bower_components/arc-polyfills/arc-polyfills.html">
</head>
```

