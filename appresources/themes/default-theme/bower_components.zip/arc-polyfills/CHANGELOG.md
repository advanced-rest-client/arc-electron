<a name="0.1.10"></a>
## [0.1.10](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.9...0.1.10) (2017-07-21)




<a name="0.1.9"></a>
## [0.1.9](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.8...0.1.9) (2017-07-21)


### Update

* Added Number.isInteger polyfill. ([75e058285cb9fce6088d82a507ee8dd55a955b53](https://github.com/advanced-rest-client/arc-polyfills/commit/75e058285cb9fce6088d82a507ee8dd55a955b53))



<a name="0.1.8"></a>
## [0.1.8](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.6...v0.1.8) (2017-06-16)




<a name="0.1.7"></a>
## [0.1.7](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.5...v0.1.7) (2017-06-16)




<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.5...v0.1.6) (2017-06-16)




<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.4...v0.1.5) (2017-05-09)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.3...v0.1.4) (2017-05-09)


### Update

* Updated Bower dependencies to a right repo ([0e263d62628f2ca6d5efcbfbda25c63539009b19](https://github.com/advanced-rest-client/arc-polyfills/commit/0e263d62628f2ca6d5efcbfbda25c63539009b19))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.2...v0.1.3) (2017-05-09)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-polyfills/compare/0.1.1...v0.1.2) (2017-05-09)


### Update

* Updated promise dependency to not create conflicts ([91d4f2e165d5b79798d1c7653b59438a14801a23](https://github.com/advanced-rest-client/arc-polyfills/commit/91d4f2e165d5b79798d1c7653b59438a14801a23))



<a name="0.1.1"></a>
## 0.1.1 (2017-05-08)


### Docs

* Updated docs ([b48273b56eea74cb03303f73a47665f2f2094002](https://github.com/advanced-rest-client/arc-polyfills/commit/b48273b56eea74cb03303f73a47665f2f2094002))

### Update

* Removed reference to tests ([306c6072ee57a2c94f1ab6aa6d2a6ae08f063346](https://github.com/advanced-rest-client/arc-polyfills/commit/306c6072ee57a2c94f1ab6aa6d2a6ae08f063346))
* Updated projects metadata ([3ec6dae2d183f21a78a39e828f7f2010e5ffe86a](https://github.com/advanced-rest-client/arc-polyfills/commit/3ec6dae2d183f21a78a39e828f7f2010e5ffe86a))



