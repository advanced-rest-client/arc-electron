<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-data-settings-panel/compare/0.1.4...0.1.5) (2017-10-02)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-data-settings-panel/compare/0.1.3...0.1.4) (2017-10-02)


### Fix

* datastore-destroyed now will report right number of databases. ([622ace28eab040e5f62b0212d64efe05ef527937](https://github.com/advanced-rest-client/arc-data-settings-panel/commit/622ace28eab040e5f62b0212d64efe05ef527937))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-data-settings-panel/compare/0.1.2...0.1.3) (2017-10-02)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-data-settings-panel/compare/0.1.1...0.1.2) (2017-10-02)


### Fix

* Adding missing import. ([5732cdd01a8ebc5fbe7a7f57960793a6a2ee1ae8](https://github.com/advanced-rest-client/arc-data-settings-panel/commit/5732cdd01a8ebc5fbe7a7f57960793a6a2ee1ae8))

### Update

* Replaced dialogs with panels ([ddc1e6d58d396f5d090507f64295afdcf5c8fde9](https://github.com/advanced-rest-client/arc-data-settings-panel/commit/ddc1e6d58d396f5d090507f64295afdcf5c8fde9))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-18)


### Fix

* Fixing tests ([00c60ed26047f3a8960d6e5aba28162b24b960d4](https://github.com/advanced-rest-client/arc-data-settings-panel/commit/00c60ed26047f3a8960d6e5aba28162b24b960d4))



