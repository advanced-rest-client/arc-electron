<a name="0.1.1"></a>
## 0.1.1 (2017-09-18)


### Update

* Added sauce configuration for tests ([4b78944e1a0c8bf941f10c7a64466e2c6c0a6d10](https://github.com/advanced-rest-client/chrome-file-export/commit/4b78944e1a0c8bf941f10c7a64466e2c6c0a6d10))



