<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-request-settings-panel/compare/0.1.2...0.1.3) (2017-09-19)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-request-settings-panel/compare/0.1.1...0.1.2) (2017-09-19)


### Update

* Added notify option to the page property ([a4aecf1670126cc60593056e489f72bae59e9c13](https://github.com/advanced-rest-client/arc-request-settings-panel/commit/a4aecf1670126cc60593056e489f72bae59e9c13))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-19)


### Update

* Added sauce configuration for tests ([a4fc0c21b8f01077c2be52efeed63e233dc8c5e6](https://github.com/advanced-rest-client/arc-request-settings-panel/commit/a4fc0c21b8f01077c2be52efeed63e233dc8c5e6))



