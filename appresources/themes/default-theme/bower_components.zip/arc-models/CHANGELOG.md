<a name="0.1.18"></a>
## [0.1.18](https://github.com/advanced-rest-client/arc-models/compare/0.1.17...0.1.18) (2017-12-22)




<a name="0.1.17"></a>
## [0.1.17](https://github.com/advanced-rest-client/arc-models/compare/0.1.16...0.1.17) (2017-12-22)


### New

* Adding host-rules model ([74a7ebf46466a32e6db73716a323e59c73d25550](https://github.com/advanced-rest-client/arc-models/commit/74a7ebf46466a32e6db73716a323e59c73d25550))



<a name="0.1.16"></a>
## [0.1.16](https://github.com/advanced-rest-client/arc-models/compare/0.1.15...0.1.16) (2017-11-21)




<a name="0.1.15"></a>
## [0.1.15](https://github.com/advanced-rest-client/arc-models/compare/0.1.14...0.1.15) (2017-11-21)


### Update

* Added support for `order` when creating an object. ([5e385c17615bee0ed6841212a508c48a4d33c8eb](https://github.com/advanced-rest-client/arc-models/commit/5e385c17615bee0ed6841212a508c48a4d33c8eb))



<a name="0.1.14"></a>
## [0.1.14](https://github.com/advanced-rest-client/arc-models/compare/0.1.13...0.1.14) (2017-11-20)




<a name="0.1.13"></a>
## [0.1.13](https://github.com/advanced-rest-client/arc-models/compare/0.1.12...0.1.13) (2017-11-20)


### New

* Added rest API model. ([b58850133f64d6f6e8d2e02c2abd4bfe4ba61199](https://github.com/advanced-rest-client/arc-models/commit/b58850133f64d6f6e8d2e02c2abd4bfe4ba61199))



<a name="0.1.12"></a>
## [0.1.12](https://github.com/advanced-rest-client/arc-models/compare/0.1.11...0.1.12) (2017-11-04)




<a name="0.1.11"></a>
## [0.1.11](https://github.com/advanced-rest-client/arc-models/compare/0.1.10...0.1.11) (2017-11-04)


### New

* Added bulk edit method ([dba4d46a14b899b236254559456395a3bd1f3e42](https://github.com/advanced-rest-client/arc-models/commit/dba4d46a14b899b236254559456395a3bd1f3e42))



<a name="0.1.10"></a>
## [0.1.10](https://github.com/advanced-rest-client/arc-models/compare/0.1.8...0.1.10) (2017-09-20)


### Update

* Updated request ID generation ([f20b01d54a6fda4a111e6d6c6b13d10e038323fc](https://github.com/advanced-rest-client/arc-models/commit/f20b01d54a6fda4a111e6d6c6b13d10e038323fc))



<a name="0.1.9"></a>
## [0.1.9](https://github.com/advanced-rest-client/arc-models/compare/0.1.8...0.1.9) (2017-09-13)




<a name="0.1.8"></a>
## [0.1.8](https://github.com/advanced-rest-client/arc-models/compare/0.1.7...0.1.8) (2017-09-13)


### Fix

* Fixed test. ([062692fc95d2e64dc25b7c17915095cef4d44422](https://github.com/advanced-rest-client/arc-models/commit/062692fc95d2e64dc25b7c17915095cef4d44422))

### New

* Added `type` property to delete/update event for request model ([850e0cd49585fe70c7ffc5f2b52e3bbe555b706b](https://github.com/advanced-rest-client/arc-models/commit/850e0cd49585fe70c7ffc5f2b52e3bbe555b706b))
* Added support for updating history objects ([35b83ab797d5b83ba2b912cc450f0c7a7d465cda](https://github.com/advanced-rest-client/arc-models/commit/35b83ab797d5b83ba2b912cc450f0c7a7d465cda))



<a name="0.1.7"></a>
## [0.1.7](https://github.com/advanced-rest-client/arc-models/compare/0.1.6...0.1.7) (2017-09-10)




<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/arc-models/compare/0.1.5...0.1.6) (2017-09-10)


### New

* Added request object restoration after the delete ([1312c9c435de04345a8cd6d13a6fc2d437d1276c](https://github.com/advanced-rest-client/arc-models/commit/1312c9c435de04345a8cd6d13a6fc2d437d1276c))



<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-models/compare/0.1.4...0.1.5) (2017-09-07)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-models/compare/0.1.3...0.1.4) (2017-09-07)




<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-models/compare/0.1.2...0.1.3) (2017-09-07)


### Fix

* Restoring tests ([8539317c962ac95dc559986105f5b7c25ec785df](https://github.com/advanced-rest-client/arc-models/commit/8539317c962ac95dc559986105f5b7c25ec785df))



<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-models/compare/0.1.1...0.1.2) (2017-09-07)


### New

* Added websocket URL history model ([d05e1e11a011efcaac463046a8cd79ac2dcc7d78](https://github.com/advanced-rest-client/arc-models/commit/d05e1e11a011efcaac463046a8cd79ac2dcc7d78))

### Update

* Updated documentation ([3be09b3ebf7b7594f53eb2755b1d8c24e370955e](https://github.com/advanced-rest-client/arc-models/commit/3be09b3ebf7b7594f53eb2755b1d8c24e370955e))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-07)




