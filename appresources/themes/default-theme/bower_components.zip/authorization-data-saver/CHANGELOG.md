<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/authorization-data-saver/compare/0.1.5...0.1.6) (2017-10-02)




<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/authorization-data-saver/compare/0.1.4...0.1.5) (2017-10-02)


### Fix

* Fixing variable name. ([6ae897229cc7c9ee95ad00f65c2c2b508ddd352e](https://github.com/advanced-rest-client/authorization-data-saver/commit/6ae897229cc7c9ee95ad00f65c2c2b508ddd352e))



<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/authorization-data-saver/compare/0.1.2...0.1.4) (2017-10-02)


### New

* Added support for request ID ([2fc2e4d1570e29129d6c7287f93cde7050dbe67c](https://github.com/advanced-rest-client/authorization-data-saver/commit/2fc2e4d1570e29129d6c7287f93cde7050dbe67c))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/authorization-data-saver/compare/0.1.2...v0.1.3) (2017-07-08)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/authorization-data-saver/compare/0.1.1...v0.1.2) (2017-07-08)




<a name="0.1.1"></a>
## 0.1.1 (2017-06-22)


### Fix

* Fixed tests! 👍 ([5087e0491940497d04bb3d68d338ec7b881fdd78](https://github.com/advanced-rest-client/authorization-data-saver/commit/5087e0491940497d04bb3d68d338ec7b881fdd78))

### Update

* Updated license file to the correct one. ([a4dc5f6d76c932b76555e7d45fbb3462d7ec1593](https://github.com/advanced-rest-client/authorization-data-saver/commit/a4dc5f6d76c932b76555e7d45fbb3462d7ec1593))
* Updated package metadata. ([d21fc3254e1a626414da8f5d63cfea087749b982](https://github.com/advanced-rest-client/authorization-data-saver/commit/d21fc3254e1a626414da8f5d63cfea087749b982))
* Updated Travis configuration to connect to Sauce Labs. ([55e388530da9430a551da9f46d6a4e01b0d12623](https://github.com/advanced-rest-client/authorization-data-saver/commit/55e388530da9430a551da9f46d6a4e01b0d12623))
* Updated Travis configuration to connect to Sauce Labs. ([e7e2c977cf30ceec5e3586b5ebd321d8835d97c6](https://github.com/advanced-rest-client/authorization-data-saver/commit/e7e2c977cf30ceec5e3586b5ebd321d8835d97c6))



