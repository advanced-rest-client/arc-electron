<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/auth-dialogs/compare/0.1.2...v0.1.3) (2017-06-21)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/auth-dialogs/compare/0.1.1...v0.1.2) (2017-06-21)


### Fix

* Added paper button dependency that was added as dev dependency. Also added the paper-button import to the `authorization-dialog.html` that was missing. ([9026b3f409e457e609bd1c0ec26fe518a7ed4eab](https://github.com/advanced-rest-client/auth-dialogs/commit/9026b3f409e457e609bd1c0ec26fe518a7ed4eab))



<a name="0.1.1"></a>
## 0.1.1 (2017-06-21)


### Update

* Removed timeout from tests due to timeout error on Safari 9 ([469ba2a35e4e1d787f4eae53ffdb63eb71682a90](https://github.com/advanced-rest-client/auth-dialogs/commit/469ba2a35e4e1d787f4eae53ffdb63eb71682a90))
* Renamed test file name ([3498f0ae45654bb88527acfcb4542118a093c7be](https://github.com/advanced-rest-client/auth-dialogs/commit/3498f0ae45654bb88527acfcb4542118a093c7be))
* Updated Travis configuration to connect to Sauce Labs ([185b1462855784812d85b229deba3411d1b815f7](https://github.com/advanced-rest-client/auth-dialogs/commit/185b1462855784812d85b229deba3411d1b815f7))



