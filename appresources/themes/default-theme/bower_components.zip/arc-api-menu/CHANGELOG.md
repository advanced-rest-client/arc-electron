<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-api-menu/compare/0.1.2...0.1.3) (2018-01-17)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-api-menu/compare/0.1.1...0.1.2) (2018-01-17)


### New

* Adding explore apis button ([6cfa7781a5869c88a09fabe03f930ba13467e159](https://github.com/advanced-rest-client/arc-api-menu/commit/6cfa7781a5869c88a09fabe03f930ba13467e159))



<a name="0.1.1"></a>
## 0.1.1 (2018-01-15)


### Update

* Updated Travis configuration to connect to Sauce Labs. ([bdd1589e9eda2a7e4763525c8b337f76e565a5fc](https://github.com/advanced-rest-client/arc-api-menu/commit/bdd1589e9eda2a7e4763525c8b337f76e565a5fc))



