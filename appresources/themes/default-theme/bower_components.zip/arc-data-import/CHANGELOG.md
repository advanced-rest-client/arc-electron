<a name="0.1.7"></a>
## [0.1.7](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.6...0.1.7) (2017-12-22)




<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.5...0.1.6) (2017-12-22)


### New

* Added support for host-rules model ([48d1e88a7ac36a11a36178561e825b673bdcc529](https://github.com/advanced-rest-client/arc-data-import/commit/48d1e88a7ac36a11a36178561e825b673bdcc529))



<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.4...0.1.5) (2017-10-21)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.3...0.1.4) (2017-10-21)


### Update

* Added new import file kinds ([2016ee4c8568b8764ca5c3ae8d44675a545428bd](https://github.com/advanced-rest-client/arc-data-import/commit/2016ee4c8568b8764ca5c3ae8d44675a545428bd))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.2...0.1.3) (2017-10-02)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-data-import/compare/0.1.1...0.1.2) (2017-10-02)


### Fix

* Added back error object ([e7d136a9c6ee1e7a7afb154982947a9998e1b715](https://github.com/advanced-rest-client/arc-data-import/commit/e7d136a9c6ee1e7a7afb154982947a9998e1b715))

### Update

* Added data-imported custom event. ([be9f54c29264752ee38a9e9209ce55887ad40c4f](https://github.com/advanced-rest-client/arc-data-import/commit/be9f54c29264752ee38a9e9209ce55887ad40c4f))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-27)


### Docs

* Updated documentation for the element. ([770e517372fd13dadbd2e773465a3434ceb98ba6](https://github.com/advanced-rest-client/arc-data-import/commit/770e517372fd13dadbd2e773465a3434ceb98ba6))

### Fix

* Added fetch polyfill for safari. ([cf50ad48a0cfde7a3b88f8641290decd645af4f1](https://github.com/advanced-rest-client/arc-data-import/commit/cf50ad48a0cfde7a3b88f8641290decd645af4f1))
* Fixing fetch for safari. ([c2f7ec3cb2372661b187e8c53127ca7850a8d12c](https://github.com/advanced-rest-client/arc-data-import/commit/c2f7ec3cb2372661b187e8c53127ca7850a8d12c))

### New

* Added event handler ([5738b0fdbfdaa7ce6897d3962eba11049dcb7d31](https://github.com/advanced-rest-client/arc-data-import/commit/5738b0fdbfdaa7ce6897d3962eba11049dcb7d31))

### Update

* Added sauce configuration for tests ([2094db6147a8376be6c0234c5968e1e1c4267c08](https://github.com/advanced-rest-client/arc-data-import/commit/2094db6147a8376be6c0234c5968e1e1c4267c08))
* updated test name. ([b1a161a4b676032d69fba9d1aceac709bb8577d2](https://github.com/advanced-rest-client/arc-data-import/commit/b1a161a4b676032d69fba9d1aceac709bb8577d2))



