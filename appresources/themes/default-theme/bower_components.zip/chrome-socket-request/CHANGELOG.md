<a name="0.0.5"></a>
## [0.0.5](https://github.com/advanced-rest-client/chrome-socket-request/compare/0.0.3...0.0.5) (2017-10-01)


### Docs

* Added documentation for events ([e7b72d14adc2b36ab1a996be0e5d70fb6ce06afb](https://github.com/advanced-rest-client/chrome-socket-request/commit/e7b72d14adc2b36ab1a996be0e5d70fb6ce06afb))

### New

* Added support for request ID. ([aa4696ce57ef3a77866759f689aa3ab20afee84b](https://github.com/advanced-rest-client/chrome-socket-request/commit/aa4696ce57ef3a77866759f689aa3ab20afee84b))



<a name="0.0.4"></a>
## [0.0.4](https://github.com/advanced-rest-client/chrome-socket-request/compare/0.0.3...0.0.4) (2017-09-01)




<a name="0.0.3"></a>
## [0.0.3](https://github.com/advanced-rest-client/chrome-socket-request/compare/0.0.2...0.0.3) (2017-09-01)


### Fix

* Fixed headers received event type ([40b43d4ac8c70c06870bf293a24e7d5087e986a2](https://github.com/advanced-rest-client/chrome-socket-request/commit/40b43d4ac8c70c06870bf293a24e7d5087e986a2))
* Fixing request time computation ([554ac3a4955e27336e626f279f79d13ca70ee463](https://github.com/advanced-rest-client/chrome-socket-request/commit/554ac3a4955e27336e626f279f79d13ca70ee463))

### Update

* Updated request processor ([53702d7e582b6386379884f009a2bc072f21103a](https://github.com/advanced-rest-client/chrome-socket-request/commit/53702d7e582b6386379884f009a2bc072f21103a))



<a name="0.0.2"></a>
## 0.0.2 (2017-08-30)


### Update

* Removed tests ([087804b9f8bccd7581108d9526a40758775203b6](https://github.com/advanced-rest-client/chrome-socket-request/commit/087804b9f8bccd7581108d9526a40758775203b6))



