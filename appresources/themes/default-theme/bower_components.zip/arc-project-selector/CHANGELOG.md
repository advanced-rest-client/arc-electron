<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/arc-project-selector/compare/0.1.4...0.1.5) (2017-11-04)




<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/arc-project-selector/compare/0.1.3...0.1.4) (2017-11-04)


### Fix

* Adding data binding for required and auto-validate ([470e00bef1dd53917161ac39a9ddb6f9533f36ee](https://github.com/advanced-rest-client/arc-project-selector/commit/470e00bef1dd53917161ac39a9ddb6f9533f36ee))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/arc-project-selector/compare/0.1.2...0.1.3) (2017-11-04)




<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/arc-project-selector/compare/0.1.1...0.1.2) (2017-11-04)


### Fix

* Moved arc-demo-helpers to dev dependencies ([b0aa823aa117027cdca0cdcb511ff63538d7e369](https://github.com/advanced-rest-client/arc-project-selector/commit/b0aa823aa117027cdca0cdcb511ff63538d7e369))



<a name="0.1.1"></a>
## 0.1.1 (2017-11-04)


### Update

* Added sauce configuration for tests ([00bccf4a92a28fa0c94c2add2d6ba9eec1e78d20](https://github.com/advanced-rest-client/arc-project-selector/commit/00bccf4a92a28fa0c94c2add2d6ba9eec1e78d20))



