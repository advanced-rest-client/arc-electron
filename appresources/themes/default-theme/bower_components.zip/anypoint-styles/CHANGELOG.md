<a name="0.1.8"></a>
## [0.1.8](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.4...v0.1.8) (2017-04-26)


### Update

* Added default theme for the anypoint ([d0dae6fbdbcccaaf94d60058814c5079fffd53a0](https://github.com/advanced-rest-client/anypoint-styles/commit/d0dae6fbdbcccaaf94d60058814c5079fffd53a0))
* Updated dropdown styles ([464a4034124b2ea33bf49f3b8ef91647e5f505dd](https://github.com/advanced-rest-client/anypoint-styles/commit/464a4034124b2ea33bf49f3b8ef91647e5f505dd))

### Upsate

* Replaced color value with variable ([48e192f8bc58b31c6cbced460f19f92c8f73f14e](https://github.com/advanced-rest-client/anypoint-styles/commit/48e192f8bc58b31c6cbced460f19f92c8f73f14e))



<a name="0.1.7"></a>
## [0.1.7](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.6...v0.1.7) (2017-04-20)




<a name="0.1.6"></a>
## [0.1.6](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.5...v0.1.6) (2017-04-20)


### Upsate

* Replaced color value with variable ([48e192f8bc58b31c6cbced460f19f92c8f73f14e](https://github.com/advanced-rest-client/anypoint-styles/commit/48e192f8bc58b31c6cbced460f19f92c8f73f14e))



<a name="0.1.5"></a>
## [0.1.5](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.2...v0.1.5) (2017-04-20)


### Docs

* Updated documentation for the dropdown-menu ([348a9d3317339bcddc63eacb3f70ba53f025e309](https://github.com/advanced-rest-client/anypoint-styles/commit/348a9d3317339bcddc63eacb3f70ba53f025e309))

### Update

* Added documentation for elements, added new element to style dropdown menu ([ffd9e763beb55c088e8a69cc872ce3ef94ac5aeb](https://github.com/advanced-rest-client/anypoint-styles/commit/ffd9e763beb55c088e8a69cc872ce3ef94ac5aeb))
* Updated dropdown styles ([464a4034124b2ea33bf49f3b8ef91647e5f505dd](https://github.com/advanced-rest-client/anypoint-styles/commit/464a4034124b2ea33bf49f3b8ef91647e5f505dd))



<a name="0.1.4"></a>
## [0.1.4](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.3...v0.1.4) (2017-04-20)


### Docs

* Updated documentation for the dropdown-menu ([348a9d3317339bcddc63eacb3f70ba53f025e309](https://github.com/advanced-rest-client/anypoint-styles/commit/348a9d3317339bcddc63eacb3f70ba53f025e309))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.2...v0.1.3) (2017-04-20)


### Update

* Added documentation for elements, added new element to style dropdown menu ([ffd9e763beb55c088e8a69cc872ce3ef94ac5aeb](https://github.com/advanced-rest-client/anypoint-styles/commit/ffd9e763beb55c088e8a69cc872ce3ef94ac5aeb))



<a name="0.1.2"></a>
## [0.1.2](https://github.com/advanced-rest-client/anypoint-styles/compare/0.1.1...v0.1.2) (2017-03-31)




<a name="0.1.1"></a>
## 0.1.1 (2017-03-31)
