<a name="1.0.5"></a>
## [1.0.5](https://github.com/advanced-rest-client/app-pouchdb-quick-search/compare/1.0.4...v1.0.5) (2017-07-08)


### Update

* Updated Travis configuration to connect to Sauce Labs. ([01e26fa1b42cada86aedde1e9f6447113c85168a](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/01e26fa1b42cada86aedde1e9f6447113c85168a))



<a name="1.0.4"></a>
## [1.0.4](https://github.com/advanced-rest-client/app-pouchdb-quick-search/compare/1.0.1...v1.0.4) (2016-10-06)


### Docs

* Updated docs file ([7c89dff9658b176980ef804196932bc0bad5f411](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/7c89dff9658b176980ef804196932bc0bad5f411))

### New

* Added hero image ([fdcf37d415c9f6dfa8ec24cf38f9f0509c0fbb44](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/fdcf37d415c9f6dfa8ec24cf38f9f0509c0fbb44))
* The query also return the 'totalRows' property alongside with 'total_rows' for jscs satisfaction ([58805eb85261de0e0f0a9e763f2dbeca9c165d1a](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/58805eb85261de0e0f0a9e763f2dbeca9c165d1a))

### Update

* Making linter happy. Leaned the code ([cbad3075a05e8f65a6108f11ce7166e8ba2e1c79](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/cbad3075a05e8f65a6108f11ce7166e8ba2e1c79))
* Updated demo page ([6755a71760b15c5290ccd9603c363a667c7f454d](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/6755a71760b15c5290ccd9603c363a667c7f454d))



<a name="1.0.3"></a>
## [1.0.3](https://github.com/advanced-rest-client/app-pouchdb-quick-search/compare/1.0.1...v1.0.3) (2016-10-06)


### Docs

* Updated docs file ([7c89dff9658b176980ef804196932bc0bad5f411](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/7c89dff9658b176980ef804196932bc0bad5f411))

### New

* The query also return the 'totalRows' property alongside with 'total_rows' for jscs satisfaction ([58805eb85261de0e0f0a9e763f2dbeca9c165d1a](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/58805eb85261de0e0f0a9e763f2dbeca9c165d1a))

### Update

* Making linter happy. Leaned the code ([cbad3075a05e8f65a6108f11ce7166e8ba2e1c79](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/cbad3075a05e8f65a6108f11ce7166e8ba2e1c79))
* Updated demo page ([6755a71760b15c5290ccd9603c363a667c7f454d](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/6755a71760b15c5290ccd9603c363a667c7f454d))



<a name="1.0.2"></a>
## [1.0.2](https://github.com/advanced-rest-client/app-pouchdb-quick-search/compare/1.0.1...v1.0.2) (2016-10-06)


### Docs

* Updated docs file ([7c89dff9658b176980ef804196932bc0bad5f411](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/7c89dff9658b176980ef804196932bc0bad5f411))

### New

* The query also return the 'totalRows' property alongside with 'total_rows' for jscs satisfaction ([58805eb85261de0e0f0a9e763f2dbeca9c165d1a](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/58805eb85261de0e0f0a9e763f2dbeca9c165d1a))

### Update

* Updated demo page ([6755a71760b15c5290ccd9603c363a667c7f454d](https://github.com/advanced-rest-client/app-pouchdb-quick-search/commit/6755a71760b15c5290ccd9603c363a667c7f454d))



<a name="1.0.1"></a>
## 1.0.1 (2016-10-01)




