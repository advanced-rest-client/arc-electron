<a name="0.1.1"></a>
## 0.1.1 (2017-09-30)


### Update

* Added sauce configuration for tests ([0c8db516d30dd53da5f10571df49e982dcfa4b16](https://github.com/advanced-rest-client/arc-license-dialog/commit/0c8db516d30dd53da5f10571df49e982dcfa4b16))



