[![Build Status](https://travis-ci.org/advanced-rest-client/arc-license-dialog.svg?branch=stage)](https://travis-ci.org/advanced-rest-client/arc-license-dialog)  

# arc-license-dialog

`<arc-license-dialog>` A license information dialog for ARC

### Example
```
<arc-license-dialog></arc-license-dialog>
```

### Styling
`<arc-license-dialog>` provides the following custom properties and mixins for styling:

Custom property | Description | Default
----------------|-------------|----------
`--arc-license-dialog` | Mixin applied to the element | `{}`

