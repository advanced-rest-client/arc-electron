<a name="1.0.1"></a>
## 1.0.1 (2016-10-07)


### New

* Added dependencyci integration ([7e53ca2b1d7d9eb57e7f25aac59e061e10268cbb](https://github.com/advanced-rest-client/app-pouchdb-collate/commit/7e53ca2b1d7d9eb57e7f25aac59e061e10268cbb))



