'use strict';

require('./tasks/lint-task.js');
require('./tasks/release.js');
