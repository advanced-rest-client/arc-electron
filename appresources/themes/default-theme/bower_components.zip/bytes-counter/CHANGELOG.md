<a name="0.1.1"></a>
## 0.1.1 (2017-06-20)


### Update

* Added sauce connect to travis configuration ([71015afb487a1e37f9a30391517c90c382721dc8](https://github.com/advanced-rest-client/bytes-counter/commit/71015afb487a1e37f9a30391517c90c382721dc8))



