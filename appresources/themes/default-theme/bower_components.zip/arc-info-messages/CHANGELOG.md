<a name="0.1.1"></a>
## 0.1.1 (2017-10-12)


### Update

* Added sauce configuration for tests ([4d75a3e767f16162759723ff1fb29e74a4fafeda](https://github.com/advanced-rest-client/arc-info-messages/commit/4d75a3e767f16162759723ff1fb29e74a4fafeda))



