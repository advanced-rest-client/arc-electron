<a name="0.5.2"></a>
## [0.5.2](https://github.com/advanced-rest-client/arc-menu/compare/0.5.1...0.5.2) (2018-01-15)




<a name="0.5.1"></a>
## [0.5.1](https://github.com/advanced-rest-client/arc-menu/compare/0.2.7...0.5.1) (2018-01-15)


### Breaking

* Complete redesign of the element and its API  ([cc7a07b43849cbed387cb2b584874a8f4ea5aac6](https://github.com/advanced-rest-client/arc-menu/commit/cc7a07b43849cbed387cb2b584874a8f4ea5aac6))



<a name="0.2.7"></a>
## [0.2.7](https://github.com/advanced-rest-client/arc-menu/compare/0.2.6...0.2.7) (2017-11-20)




<a name="0.2.6"></a>
## [0.2.6](https://github.com/advanced-rest-client/arc-menu/compare/0.2.5...0.2.6) (2017-11-20)


### New

* Added navigation to project pages. ([45af4dc225c5ee0804d72ac2872cce371b1b7318](https://github.com/advanced-rest-client/arc-menu/commit/45af4dc225c5ee0804d72ac2872cce371b1b7318))

### Update

* Moved data generator to demo page. ([f33ec125ae6b5e6cb433dfc4ac400fbce821142b](https://github.com/advanced-rest-client/arc-menu/commit/f33ec125ae6b5e6cb433dfc4ac400fbce821142b))



<a name="0.2.5"></a>
## [0.2.5](https://github.com/advanced-rest-client/arc-menu/compare/0.2.4...0.2.5) (2017-11-06)




<a name="0.2.4"></a>
## [0.2.4](https://github.com/advanced-rest-client/arc-menu/compare/0.2.3...0.2.4) (2017-11-06)


### New

* Added REST APIs menu entry. ([00e95fedf7e14327256a1f9519affbe36dbc164f](https://github.com/advanced-rest-client/arc-menu/commit/00e95fedf7e14327256a1f9519affbe36dbc164f))
* Added tests from APIs menu. ([d12e0891e6faa41b2f3bdb592db04ba8a1368ba8](https://github.com/advanced-rest-client/arc-menu/commit/d12e0891e6faa41b2f3bdb592db04ba8a1368ba8))

### Update

* Changed property name. ([342bca96b3f9d61d1a418b29982a4fc2f91039ee](https://github.com/advanced-rest-client/arc-menu/commit/342bca96b3f9d61d1a418b29982a4fc2f91039ee))



<a name="0.2.3"></a>
## [0.2.3](https://github.com/advanced-rest-client/arc-menu/compare/0.2.2...0.2.3) (2017-10-14)




<a name="0.2.2"></a>
## [0.2.2](https://github.com/advanced-rest-client/arc-menu/compare/0.2.1...0.2.2) (2017-10-14)




<a name="0.2.1"></a>
## 0.2.1 (2017-09-30)


### Breaking

* removed bottom menu. ([5e30226e9ed8748088e1239837a895cc7411a6b4](https://github.com/advanced-rest-client/arc-menu/commit/5e30226e9ed8748088e1239837a895cc7411a6b4))

### Update

* Added sauce configuration for tests ([a63be3a2a954c78f964e86458384f1c8bb00f3b0](https://github.com/advanced-rest-client/arc-menu/commit/a63be3a2a954c78f964e86458384f1c8bb00f3b0))



<a name="0.1.1"></a>
## 0.1.1 (2017-09-14)


### Update

* Added sauce configuration for tests ([a63be3a2a954c78f964e86458384f1c8bb00f3b0](https://github.com/advanced-rest-client/arc-menu/commit/a63be3a2a954c78f964e86458384f1c8bb00f3b0))



