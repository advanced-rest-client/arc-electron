<a name="0.1.1"></a>
## 0.1.1 (2017-08-28)


### Docs

* Updated documentation ([eb181ce10af16f7685cdbb44781bc08463645144](https://github.com/advanced-rest-client/chrome-connect/commit/eb181ce10af16f7685cdbb44781bc08463645144))

### Update

* Added sauce configuration for tests ([12c67c80a3e596b16115c656d9f3bd3a36a24340](https://github.com/advanced-rest-client/chrome-connect/commit/12c67c80a3e596b16115c656d9f3bd3a36a24340))



